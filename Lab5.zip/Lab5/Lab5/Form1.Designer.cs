﻿namespace Lab5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            DadJoke = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.Bottom;
            button1.AutoSize = true;
            button1.Font = new Font("Calibri", 18F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(352, 515);
            button1.Name = "button1";
            button1.Size = new Size(400, 100);
            button1.TabIndex = 0;
            button1.Text = "Give me a dad joke!";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // DadJoke
            // 
            DadJoke.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            DadJoke.AutoSize = true;
            DadJoke.Font = new Font("Calibri", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            DadJoke.ForeColor = SystemColors.ButtonHighlight;
            DadJoke.Location = new Point(352, 163);
            DadJoke.MaximumSize = new Size(400, 400);
            DadJoke.MinimumSize = new Size(400, 200);
            DadJoke.Name = "DadJoke";
            DadJoke.Size = new Size(400, 200);
            DadJoke.TabIndex = 2;
            DadJoke.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            AutoSize = true;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(1206, 693);
            Controls.Add(DadJoke);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label DadJoke;
    }
}