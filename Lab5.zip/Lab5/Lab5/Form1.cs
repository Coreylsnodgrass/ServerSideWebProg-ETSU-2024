using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;



namespace Lab5
{
    public partial class Form1 : Form
    {

        private readonly HttpClient client = new HttpClient();
        public Form1()
        {

            InitializeComponent();
            DadJoke.Text = "If you are looking for a joke, that requires a mirror... \n Press the button, that could work too.";

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            await GetDadJoke();
        }
        private async Task GetDadJoke()
        {
            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri("https://dad-jokes.p.rapidapi.com/random/joke"),
                Headers =
                {
                    { "X-RapidAPI-Key", "96dc2cedbemsh129f8d3947e1603p13d9edjsnbbe4f1cbe726" },
                    { "X-RapidAPI-Host", "dad-jokes.p.rapidapi.com" },
                },
            };
            try
            {
                using (var response = await client.SendAsync(request))
                {
                    response.EnsureSuccessStatusCode();
                    string body = await response.Content.ReadAsStringAsync();
                    var joke = JsonConvert.DeserializeObject<JokeResponse>(body);

                    if (joke?.Success == true && joke.Body.Any())
                    {
                        string setup = joke.Body[0].Setup;
                        string punchline = joke.Body[0].Punchline;
                        //DadJoke.Text = body; //------------------------ // Raw json data for testing output
                        DadJoke.Text = $"{setup}\n\n{punchline}";    // this is the Label that displays text
                        button1.Text = "Give me another dad joke!";  //This is the button label

                        // Write to dadjoke.txt
                        await File.WriteAllTextAsync("dadjoke.txt", $"{setup}\n{punchline}");
                    }
                }
            }
            catch (HttpRequestException ex)
            {
                MessageBox.Show("Error getting the dad joke: " + ex.Message);
            }



        }
        public class Joke
        {
            [JsonProperty("setup")]
            public string Setup { get; set; }

            [JsonProperty("punchline")]
            public string Punchline { get; set; }
        }

        public class JokeResponse
        {
            [JsonProperty("body")]
            public List<Joke> Body { get; set; }

            [JsonProperty("success")]
            public bool Success { get; set; }
        }


    }
}